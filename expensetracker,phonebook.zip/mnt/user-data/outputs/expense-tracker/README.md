# Expense Tracker

A console-based expense tracker in Python that allows users to add, view, delete expenses with category-wise classification and a detailed summary.

## Features
- Add expenses with category, description, and amount
- View all recorded expenses in a formatted table
- Delete any expense by selecting its number
- Summary showing total spending and category-wise breakdown with percentage
- Categories: Food, Travel, Education, Shopping, Health, Entertainment, Other

## Technologies Used
- Python 3
- Lists and Dictionaries
- Modular functions (add, delete, display, summarize)

## How to Run

### Requirements
- Python 3 installed on your computer

### Steps
```
python expense_tracker.py
```

### Using Online Compiler:
1. Go to https://www.onlinegdb.com/
2. Select language as Python 3
3. Paste the code from expense_tracker.py
4. Click Run

## Project Structure
```
expense-tracker/
├── expense_tracker.py   → Main Python source code
└── README.md            → Project description
```

## Sample Output
```
  Expense Tracker - Python
  ================================
  1. Add Expense
  2. View All Expenses
  3. Delete Expense
  4. Show Summary
  5. Exit

  Enter your choice: 1
  Choose category (1-7): 1
  Enter description : Lunch
  Enter amount (₹)  : 150
  ✅ Expense of ₹150.00 added under 'Food'.
```
