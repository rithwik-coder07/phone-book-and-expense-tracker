# Phone Book using Linked List

A console-based phone book application in C using a singly linked list to store, search, and delete contacts dynamically.

## Features
- Add new contacts (name + phone number)
- Display all saved contacts
- Search contact by name
- Delete contact by name
- Dynamic memory allocation using malloc and free

## Technologies Used
- C Language
- Singly Linked List
- Structs and Pointers
- Dynamic Memory Allocation (malloc, free)

## How to Run

### Using GCC compiler:
```
gcc phonebook.c -o phonebook
./phonebook
```

### Using Online Compiler:
1. Go to https://www.onlinegdb.com/
2. Select language as C
3. Paste the code from phonebook.c
4. Click Run

## Project Structure
```
phonebook/
├── phonebook.c   → Main C source code
└── README.md     → Project description
```

## Sample Output
```
  Phone Book Application
  =============================
  1. Add Contact
  2. Display All Contacts
  3. Search Contact
  4. Delete Contact
  5. Exit

  Enter your choice: 1
  Enter Name  : Rithwik
  Enter Phone : 7675832291
  Contact added successfully!
```
