# Interactive Resume Builder

A two-panel web application where users fill a form on the left and the resume generates live on the right in real time.

## Features
- Real-time resume preview using vanilla JavaScript oninput events
- No external frameworks required
- Print-to-PDF functionality to export resume directly from the browser
- Responsive layout using Bootstrap 5

## Technologies Used
- HTML5
- CSS3
- Bootstrap 5
- JavaScript (Vanilla)

## How to Run
1. Download or clone this repository
2. Open `index.html` in any web browser
3. Fill in your details on the left panel
4. Your resume updates live on the right panel
5. Click "Export as PDF" to save your resume

## Project Structure
```
resume-builder/
├── index.html    → Main webpage
├── style.css     → Styling and layout
├── script.js     → Live preview logic
└── README.md     → Project description
```
