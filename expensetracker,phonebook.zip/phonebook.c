#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ─── NODE STRUCTURE ───────────────────────────────────────────
struct Contact {
    char name[50];
    char phone[15];
    struct Contact* next;
};

// ─── CREATE A NEW CONTACT NODE ────────────────────────────────
struct Contact* createContact(char* name, char* phone) {
    struct Contact* newContact = (struct Contact*)malloc(sizeof(struct Contact));
    strcpy(newContact->name, name);
    strcpy(newContact->phone, phone);
    newContact->next = NULL;
    return newContact;
}

// ─── ADD CONTACT TO THE LIST ──────────────────────────────────
struct Contact* addContact(struct Contact* head, char* name, char* phone) {
    struct Contact* newContact = createContact(name, phone);
    if (head == NULL) {
        return newContact;
    }
    struct Contact* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newContact;
    return head;
}

// ─── DISPLAY ALL CONTACTS ─────────────────────────────────────
void displayContacts(struct Contact* head) {
    if (head == NULL) {
        printf("\n  No contacts found.\n");
        return;
    }
    printf("\n  %-20s %-15s\n", "Name", "Phone Number");
    printf("  ----------------------------------------\n");
    struct Contact* temp = head;
    while (temp != NULL) {
        printf("  %-20s %-15s\n", temp->name, temp->phone);
        temp = temp->next;
    }
}

// ─── SEARCH CONTACT BY NAME ───────────────────────────────────
void searchContact(struct Contact* head, char* name) {
    struct Contact* temp = head;
    int found = 0;
    while (temp != NULL) {
        if (strcmp(temp->name, name) == 0) {
            printf("\n  Contact Found!\n");
            printf("  Name  : %s\n", temp->name);
            printf("  Phone : %s\n", temp->phone);
            found = 1;
            break;
        }
        temp = temp->next;
    }
    if (!found) {
        printf("\n  Contact '%s' not found.\n", name);
    }
}

// ─── DELETE CONTACT BY NAME ───────────────────────────────────
struct Contact* deleteContact(struct Contact* head, char* name) {
    if (head == NULL) {
        printf("\n  Phone book is empty.\n");
        return NULL;
    }

    // If first node matches
    if (strcmp(head->name, name) == 0) {
        struct Contact* temp = head;
        head = head->next;
        free(temp);
        printf("\n  Contact '%s' deleted successfully.\n", name);
        return head;
    }

    // Search in rest of list
    struct Contact* prev = head;
    struct Contact* curr = head->next;
    while (curr != NULL) {
        if (strcmp(curr->name, name) == 0) {
            prev->next = curr->next;
            free(curr);
            printf("\n  Contact '%s' deleted successfully.\n", name);
            return head;
        }
        prev = curr;
        curr = curr->next;
    }

    printf("\n  Contact '%s' not found.\n", name);
    return head;
}

// ─── FREE ALL MEMORY ──────────────────────────────────────────
void freeList(struct Contact* head) {
    struct Contact* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
    }
}

// ─── MAIN MENU ────────────────────────────────────────────────
int main() {
    struct Contact* head = NULL;
    int choice;
    char name[50], phone[15];

    printf("\n  =============================");
    printf("\n       Phone Book Application   ");
    printf("\n  =============================\n");

    while (1) {
        printf("\n  1. Add Contact");
        printf("\n  2. Display All Contacts");
        printf("\n  3. Search Contact");
        printf("\n  4. Delete Contact");
        printf("\n  5. Exit");
        printf("\n\n  Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // clear newline

        switch (choice) {
            case 1:
                printf("  Enter Name  : ");
                fgets(name, sizeof(name), stdin);
                name[strcspn(name, "\n")] = 0;
                printf("  Enter Phone : ");
                fgets(phone, sizeof(phone), stdin);
                phone[strcspn(phone, "\n")] = 0;
                head = addContact(head, name, phone);
                printf("\n  Contact added successfully!\n");
                break;

            case 2:
                displayContacts(head);
                break;

            case 3:
                printf("  Enter Name to Search: ");
                fgets(name, sizeof(name), stdin);
                name[strcspn(name, "\n")] = 0;
                searchContact(head, name);
                break;

            case 4:
                printf("  Enter Name to Delete: ");
                fgets(name, sizeof(name), stdin);
                name[strcspn(name, "\n")] = 0;
                head = deleteContact(head, name);
                break;

            case 5:
                freeList(head);
                printf("\n  Exiting Phone Book. Goodbye!\n\n");
                return 0;

            default:
                printf("\n  Invalid choice. Please try again.\n");
        }
    }
}
