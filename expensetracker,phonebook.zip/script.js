// This function runs every time any input field changes
function updateResume() {

  // Personal Info
  const name     = document.getElementById('name').value || 'Your Name';
  const jobtitle = document.getElementById('jobtitle').value || 'Job Title';
  const email    = document.getElementById('email').value || 'email';
  const phone    = document.getElementById('phone').value || 'phone';
  const location = document.getElementById('location').value || 'location';
  const linkedin = document.getElementById('linkedin').value || 'linkedin';

  // Summary
  const summary  = document.getElementById('summary').value || 'Your summary will appear here...';

  // Education
  const edu1 = document.getElementById('edu1').value;
  const edu2 = document.getElementById('edu2').value;
  const edu3 = document.getElementById('edu3').value;

  // Skills
  const skills = document.getElementById('skills').value;

  // Projects
  const proj1title = document.getElementById('proj1title').value;
  const proj1desc  = document.getElementById('proj1desc').value;
  const proj2title = document.getElementById('proj2title').value;
  const proj2desc  = document.getElementById('proj2desc').value;

  // Update Preview
  document.getElementById('prev-name').textContent     = name;
  document.getElementById('prev-jobtitle').textContent = jobtitle;
  document.getElementById('prev-contact').textContent  = `${email}  |  ${phone}  |  ${location}  |  ${linkedin}`;
  document.getElementById('prev-summary').textContent  = summary;

  document.getElementById('prev-edu1').textContent = edu1;
  document.getElementById('prev-edu2').textContent = edu2;
  document.getElementById('prev-edu3').textContent = edu3;

  document.getElementById('prev-skills').textContent = skills;

  // Project 1
  if (proj1title) {
    document.getElementById('prev-proj1').innerHTML = `
      <p class="proj-title">🔹 ${proj1title}</p>
      <p class="proj-desc">${proj1desc}</p>
    `;
  }

  // Project 2
  if (proj2title) {
    document.getElementById('prev-proj2').innerHTML = `
      <p class="proj-title">🔹 ${proj2title}</p>
      <p class="proj-desc">${proj2desc}</p>
    `;
  }
}
