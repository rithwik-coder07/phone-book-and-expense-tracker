# ─────────────────────────────────────────────
#         Expense Tracker - Python
# ─────────────────────────────────────────────

expenses = []  # List of expense dictionaries

CATEGORIES = ["Food", "Travel", "Education", "Shopping", "Health", "Entertainment", "Other"]


# ─── ADD EXPENSE ──────────────────────────────
def add_expense():
    print("\n  Categories:")
    for i, cat in enumerate(CATEGORIES, 1):
        print(f"    {i}. {cat}")

    try:
        cat_choice = int(input("\n  Choose category (1-7): "))
        if cat_choice < 1 or cat_choice > 7:
            print("  Invalid category.")
            return
        category = CATEGORIES[cat_choice - 1]

        description = input("  Enter description      : ").strip()
        amount      = float(input("  Enter amount (₹)       : "))

        expense = {
            "category"    : category,
            "description" : description,
            "amount"      : amount
        }

        expenses.append(expense)
        print(f"\n  ✅ Expense of ₹{amount:.2f} added under '{category}'.")

    except ValueError:
        print("  Invalid input. Please enter numbers where required.")


# ─── DELETE EXPENSE ───────────────────────────
def delete_expense():
    if not expenses:
        print("\n  No expenses to delete.")
        return

    display_expenses()
    try:
        index = int(input("\n  Enter expense number to delete: ")) - 1
        if 0 <= index < len(expenses):
            removed = expenses.pop(index)
            print(f"\n  ✅ Deleted: {removed['description']} (₹{removed['amount']:.2f})")
        else:
            print("  Invalid number.")
    except ValueError:
        print("  Invalid input.")


# ─── DISPLAY ALL EXPENSES ─────────────────────
def display_expenses():
    if not expenses:
        print("\n  No expenses recorded yet.")
        return

    print("\n  {:<5} {:<15} {:<25} {:>10}".format("No.", "Category", "Description", "Amount (₹)"))
    print("  " + "-" * 58)
    for i, exp in enumerate(expenses, 1):
        print("  {:<5} {:<15} {:<25} {:>10.2f}".format(
            i, exp['category'], exp['description'], exp['amount']
        ))


# ─── SUMMARY ──────────────────────────────────
def show_summary():
    if not expenses:
        print("\n  No expenses to summarize.")
        return

    total = sum(exp['amount'] for exp in expenses)
    category_totals = {}

    for exp in expenses:
        cat = exp['category']
        category_totals[cat] = category_totals.get(cat, 0) + exp['amount']

    print("\n  ════════════════════════════════")
    print("        Expense Summary           ")
    print("  ════════════════════════════════")
    print(f"\n  Total Spending : ₹{total:.2f}")
    print("\n  Category-wise Breakdown:")
    print("  " + "-" * 35)
    for cat, amt in sorted(category_totals.items(), key=lambda x: -x[1]):
        percentage = (amt / total) * 100
        print(f"  {cat:<20} ₹{amt:>8.2f}  ({percentage:.1f}%)")
    print("  " + "-" * 35)


# ─── MAIN MENU ────────────────────────────────
def main():
    print("\n  ================================")
    print("       Expense Tracker - Python    ")
    print("  ================================")

    while True:
        print("\n  1. Add Expense")
        print("  2. View All Expenses")
        print("  3. Delete Expense")
        print("  4. Show Summary")
        print("  5. Exit")

        choice = input("\n  Enter your choice: ").strip()

        if choice == '1':
            add_expense()
        elif choice == '2':
            display_expenses()
        elif choice == '3':
            delete_expense()
        elif choice == '4':
            show_summary()
        elif choice == '5':
            print("\n  Exiting Expense Tracker. Goodbye!\n")
            break
        else:
            print("  Invalid choice. Please enter 1-5.")


if __name__ == "__main__":
    main()
